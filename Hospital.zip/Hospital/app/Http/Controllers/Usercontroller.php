<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Support\Facades\Auth;




class Usercontroller extends Controller
{
    
    
    public function signinpost(Request $request)
{
    $data = $request->validate([
        "name"  => "required",
        "Birth"  => "required",
        "Contact"  => "required",
        "Gender"  => "required",
        "Address"  => "required",
        "Email"  => "required|email",
        "password"  => "required|min:6" // Use lowercase "password"
    ]);

    // Hash password before saving
    $data['password'] = Hash::make($data['password']);

    $user = User::create($data);

    if ($user) {
        return redirect()->route('Login')->with('success', 'User registered successfully');
    }

    return back()->with('error', 'Failed to register');
}


    
public function loginpost(Request $request)
{
    $credentials = $request->validate([
        'Email' => 'required|email',
        'password' => 'required|min:6' // Ensure lowercase "password"
    ]);

    if (Auth::attempt(['Email' => $credentials['Email'], 'password' => $credentials['password']])) {
        $request->session()->regenerate();
        return redirect()->route('Profile');
    }

    return redirect()->route('Signin');
}

    public function profile()
    {
        $user = Auth::user();
        return view('Profile', compact('user'));
    }
    public function update($Email)
    {
        $user = User::where('Email', $Email)->firstOrFail();
        return view('update', compact('user'));
    }
    // Logout function
    public function logout(Request $request)
    {
        Auth::logout(); // Log the user out
    
        $request->session()->invalidate();
        $request->session()->regenerateToken();
    
        return redirect()->route('welcome');
    }
    public function userupdate(Request $request, $Email)
    {
        $request->validate([
            'name' => 'required',
            'Contact' => 'required',
            'Gender' => 'required|string',
            'Birth' => 'required|date',
            'Address' => 'required|string|max:255'
        ]);
    
        $user = User::where('Email', $Email)->firstOrFail();
    
        // Update user fields
        $user->name = $request->name;
        $user->Contact = $request->Contact;
        $user->Gender = $request->Gender;
        $user->Birth = $request->Birth;
        $user->Address = $request->Address;
        
        $user->save(); // Save updated data to the database
    
        return redirect()->route('profile')->with('success', 'User updated successfully!');

    }
   

    public function adduser()
    {
        $user = DB::table('_users')
        ->insert([
            'name'=>'diya',
            'Birth'=> '1999/12/2',
            'contact'=> '1234567878',
            'Gender'=>'female',
            'Address'=>'surat',
            'Email'=>'diya123@gmail.come',
            'Password'=>'123',
            'created_at'=>now(),
            'Updated_at'=>now()

        ]);
        dd($user);

    }
    
}
