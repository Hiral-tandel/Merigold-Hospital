<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable // Change this from Model to Authenticatable
{
    use HasFactory, Notifiable;

    protected $table = '_users'; // Ensure this matches your database table name

    protected $fillable = [
        'name', 'Birth', 'Contact', 'Gender', 'Address', 'Email', 'password' // Ensure lowercase "password"
    ];

    protected $hidden = [
        'password', // Ensure lowercase "password"
        'remember_token',
    ];
}
