<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="styles.css">
</head>
<style>
    /* General Styles */

/* Login Box */
.login-container {
    background:#FFF;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    width: 300px;
    text-align: center;
        margin-top: 10%; /* Pushes login form down */
        margin-left: 40%;
        margin-right: 30%;

}

h2 {
    margin-bottom: 20px;
}

/* Input Fields */
.input-group {
    margin-bottom: 15px;
    text-align: left;
}

label {
    display: block;
    font-size: 14px;
    margin-bottom: 5px;
    text-align: left;
}

input {
    width: 100%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
}

/* Forgot Password */
.forgot-password {
    text-align: right;
    margin-bottom: 10px;
}

.forgot-password a {
    color: black;
    text-decoration: none;
    font-size: 12px;
}

/* Login Button */
.login-btn {
    width: 100%;
    padding: 10px;
    background-color:#002D72;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

.login-btn:hover {
    background-color:Black;
}

/* Signup Link */
.signup-text {
    font-size: 14px;
    margin-top: 15px;
}

.signup-text a {
    color:black;
    text-decoration: none;
}

</style>

<body style="background: url('/images/bg.png') no-repeat center center fixed;
    background-size: cover;" >

  <div class="container">
    <div class="login-container"> <!-- Added mt-5 -->
        <h2>Login</h2>
        
        <form action="<?php echo e(route('Loginpost')); ?>" method="POST">
        <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="Email">Email</label>
                <input type="Email" id="Email"  name ="Email" class="form-control" placeholder="Enter your email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" class="form-control" placeholder="Enter your password" required>
            </div>
            <div class="forgot-password">
                <a href="#">Forgot Password?</a>
            </div>
            <button type="submit" class="login-btn">Login</button>
            <p class="signup-text">Don't have an account? <a href="<?php echo e(route('Signin')); ?>">Sign up</a></p>
            <p class="signup-text">profile <a href="<?php echo e(route('Profile')); ?>">User</a></p>



        </form>
    </div>
</div>

</body>
</html>

<?php /**PATH C:\Users\User\Firstlaravel\Hospital\resources\views/Login.blade.php ENDPATH**/ ?>