<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Usercontroller;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/Login', function () {
    return view('Login'); // This should match the Laravel authentication view
})->name('Login');

Route::get('/Signin', function () {
    return view('Signin'); // This should match the Laravel authentication view
})->name('Signin');

Route::get('/About', function () {
    return view('About'); // This should match the Laravel authentication view
})->name('About');

Route::get('/Docter', function () {
    return view('Docter'); // This should match the Laravel authentication view
})->name('Docter');


Route::get('/Review', function () {
    return view('Review'); // This should match the Laravel authentication view
})->name('Review');


Route::get('/welcome', function () {
    return view('welcome'); // This should match the Laravel authentication view
})->name('welcome');


Route::get('/Appointment', function () {
    return view('Appointment'); // This should match the Laravel authentication view
})->name('Appointment');

Route::get('/update/{Email}', [UserController::class, 'update'])->name('update');


Route::middleware('auth')->get('/Profile', [UserController::class, 'profile'])->name('Profile');



Route::get('/add',[Usercontroller::class,'addUser']);

Route::Post('/Signinpost', [Usercontroller::class, 'Signinpost'])->name('Signinpost');
Route::post('/Loginpost', [UserController::class, 'loginpost'])->name('Loginpost');
Route::get('/Logout', [UserController::class, 'logout'])->name('Logout');
Route::post('/userupdate/{Email}', [UserController::class, 'userupdate'])->name('userupdate');
Route::get('/profile', [UserController::class, 'profile'])->name('profile');


// Protect profile page

Route::post('/logout', [Usercontroller::class, 'logout'])->name('logout');




