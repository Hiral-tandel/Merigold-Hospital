<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navigation with Shop Name</title>
    <style>
        body {
            margin: 0;
            font-family: sans-serif;
        }

        nav {
            background-color: #219ebc;
            overflow: hidden;
            display: flex;
            justify-content: space-between; /* Distribute space between shop name and links */
            align-items: center; /* Vertically center items */
            padding: 0 15px; /* Add padding to the left and right */
        }

        nav .shop-name {
            color: black;
            font-size: 1.5em; /* Adjust font size as needed */
            font-weight: bold;
            text-decoration: none;
            
        }

        nav .nav-links {
            display: flex; /* Display links horizontally */
        }

        nav .nav-links a {
            color: black;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
            font-size: 20px;
                }

        nav .nav-links a:hover {
            color: #FFFF;
            font-size: 22px;
        }

        

        
  footer {
            background-color: #219ebc;
            padding: 20px;
            margin-top: auto;
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }

        footer div {
            margin-bottom: 20px;
        }

        footer h3 {
            margin-bottom: 10px;
        }
        footer h3:hover{
            color:#fff;
        }
        footer a:hover{
            color:#FFF;
            font-size: 20px;

        }

        footer a {
            display: block;
            text-decoration: none;
            color: #333;
            margin-bottom: 5px;
        }
        footer p:hover{
            color:#FFF;
            font-size: 19px;


        }
    </style>
</head>
<body>

    <nav>
        <a href="#" class="shop-name">Marigold hospital</a>
        <div class="nav-links">
            <a href="{{ route('welcome') }}">Home</a>
            <a href="{{ route('About') }}">About</a>
            <a href="{{ route('Docter') }}">Docter</a>
            <a href="{{ route('Review') }}">Review</a>
            <a href="{{ route('Appointment') }}">Appointment</a>
            <a href="{{ route('welcome') }}">Contact</a>
           
@if(Auth::check())
    <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
    <button
             style="background-color: #002D72; color: white;padding: 11px 17px; border: none;text-align: center;border-radius:10px; cursor: pointer;"
             onmouseover="this.style.backgroundColor='black'"
             onmouseout="this.style.backgroundColor='#002D72'"
             >
    Logout
</button></a>
    </a>
    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
        @csrf
    </form>
@else
    <a href="{{ route('Login') }}"> <button
             style="background-color: #002D72; color: white;padding: 11px 17px; border: none;text-align: center;border-radius:10px; cursor: pointer;"
             onmouseover="this.style.backgroundColor='black'"
             onmouseout="this.style.backgroundColor='#002D72'"
             >
    Login
</button></a>
@endif

        </div>
    </nav>

    <main>
        @yield('content')

       
    </main>
 



    <footer>
   <div>
            <h3>Quick Links</h3>
            <a href="#home">Home</a>
            <a href="#about">About Us</a>
            <a href="#services">Docter</a>
            <a href="#products">Review</a>
            <a href="#products">Appointment</a>
            <a href="#contact">Contact Us</a>
            
        </div>
        <div>
            <h3>Contact Us</h3>
            <p>Email:Marigold hospital123@gmail.com</p>
            <p>Phone: +1 555-123-4567</p>
        </div>
        <div>
            <h3>Address</h3>
            <p>123 Main Street</p>
            <p>City, State, ZIP Code</p>
            <p>Country</p>

        </div>

        </footer>

</body>
</html>
