@extends('layout')
@section('content')

<img src="images/home.png" alt="Girl in a jacket" width="1580" height="600">
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Cards</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .header {
            background-color: #002D72;
            color: white;
            padding: 20px;
            font-size: 24px;
            font-weight: bold;
        }
        .container {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 20px;
        }
        .card {
            background: white;
            width: 200px;
            padding: 20px;
            margin: 15px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
        }
        .card img {
            width: 50px;
            margin-bottom: 10px;
        }
        .card h3 {
            margin: 10px 0;
            font-size: 18px;
        }
    </style>
</head>
<body>

    <div class="header">JOHNS HOPKINS MEDICINE</div>

    <div class="container">
        <div class="card">
            <img src="stethoscope-icon.png" alt="Doctors">
            <h3>Doctors</h3>
            <p>Search for doctors by name.</p>
        </div>
        <div class="card">
            <img src="location-icon.png" alt="Locations">
            <h3>Locations</h3>
            <p>Find care in an area.</p>
        </div>
        <div class="card">
            <img src="calendar-icon.png" alt="Appointments">
            <h3>Appointments</h3>
            <p>Schedule an appointment.</p>
        </div>
        <div class="card">
            <img src="user-icon.png" alt="MyChart">
            <h3>MyChart</h3>
            <p>View test results and schedule visits.</p>
        </div>
    </div>

</body>
</html>

@endsection
