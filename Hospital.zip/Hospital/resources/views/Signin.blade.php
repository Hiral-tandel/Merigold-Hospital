<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="styles.css">
</head>
<style>
    /* General Styles */

/* Login Box */
.login-container {
    background-color:#FFFFFF;    ;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    width: 300px;
    text-align: center;
    margin-top: 5%; /* Pushes login form down */
    margin-left: 40%;
    margin-right: 30%;

}

h2 {
    margin-bottom: 20px;
}

/* Input Fields */
.input-group {
    margin-bottom: 15px;
    text-align: left;
}

label {
    display: block;
    font-size: 14px;
    margin-bottom: 5px;
    text-align: left;
}

input {
    width: 100%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
}

/* Forgot Password */
.forgot-password {
    text-align: right;
    margin-bottom: 10px;
}

.forgot-password a {
    color: black;
    text-decoration: none;
    font-size: 12px;
}

/* Login Button */
.login-btn {
    width: 100%;
    padding: 10px;
    background-color:#002D72;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

.login-btn:hover {
    background-color:Black;
}

/* Signup Link */
.signup-text {
    font-size: 14px;
    margin-top: 15px;
}

.signup-text a {
    color:black;
    text-decoration: none;
}

</style>

<body style="background: url('/images/bg.png') no-repeat center center fixed;
    background-size: cover;" >

  <div class="container">
    <div class="login-container"> <!-- Added mt-5 -->
        <h2> User Sigin</h2>
        
        <form action="{{route('Signinpost')}}" method="POST">
        @csrf
        <div class="form-group">
                <label for="email">Full Name</label>
                <input type="text" name="name" id="name" class="form-control" placeholder="Enter your Name" >
            </div>
            <div class="form-group">
                <label for="email">Date Of Birth</label>
                <input type="Date"name="Birth"  id="date" class="form-control" placeholder="Enter your Date Of Birth" >
            </div>
            <div class="form-group">
                <label for="email">Contact Number</label>
                <input type="number" name="Contact" id="num" class="form-control" placeholder="Enter your Contact Number" required>
            </div>
            <div class="form-group">
                <label for="email">Gender</label>
                <input type="Text" name="Gender" id="gender" class="form-control" placeholder="Enter your Contact Gender" required>
            </div>
            <div class="form-group">
                <label for="email">Address</label>
                <input type="Text" name="Address" id="Address" class="form-control" placeholder="Enter your " required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email"  name="Email" id="email" class="form-control" placeholder="Enter your email" required>
            </div>
            <div class="form-group">
                <label for="email">Password</label>
                <input type="Password" name="Password" id="password" class="form-control" placeholder="Enter your Password" required>
            </div>
            
            <button type="submit" class="login-btn">Submit</button>
            <p class="signup-text">Goto Login <a href="{{ route('Login') }}">Login</a></p>


        </form>
    </div>
</div>

</body>
</html>
@if ($errors->any())
    <div style="color: red;">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

