@extends('layout')
@section('content')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile & Form Layout</title>
    <link rel="stylesheet" href="styles.css">
</head>
<style>
    /* General Styles */


/* Container Layout */
.container {
    display: flex;
    background: white;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
    overflow: hidden;
    width: 1540px;
}

/* Profile Section */
.profile {
    width: 30%;
    background: #f9f9f9;
    padding: 20px;
    text-align: center;
    border-right: 1px solid #ddd;
}

.profile img {
    width: 110px;
    height: 110px;
    border-radius: 70%;
    margin-bottom: 10px;
}

.profile h3 {
    margin: 5px 0;
    font-size: 18px;
}

.profile p {
    color: #777;
    font-size: 14px;
}

.profile h4 {
    margin-top: 15px;
    font-size: 16px;
    color: #333;
}

/* Form Section */
.form-container {
    width: 100%;
    padding: 20px;
}

/* Form Group */
.form-group {
    display: inline-block;
    width: 80%;
    margin: 10px 1%;
}

.form-group label {
    display: block;
    font-size: 14px;
    font-weight: bold;
    margin-bottom: 5px;
}

.form-group input {
    width: 100%;
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 14px;
}

/* Button Group */
.btn-group {
    margin-top: 20px;
    text-align: right;
}

button {
    padding: 8px 15px;
    font-size: 14px;
    border: none;
    cursor: pointer;
    border-radius: 5px;
    background-color:#002D72;
    color : #FFFF;


}

button:hover {
    opacity: 0.8;
}
.box{
    background:#002D72;
    border-radius : 5px;
    width: 100%;
height:30px;

}
.box h2{
    color:#FFFF;
    margin-left: 5px;
margin-top: 2px;
}

</style>
<body>
    <div class="container">
        <!-- Profile Section -->
        <div class="profile">
            <img src="/images/profile.png ">

            <h3>User Name : </h3>
            <input type="text" name="name" value="{{ $user->name }}">

            <p>Email : </p>
            <p>{{ $user->Email }}</p>
        

        </div>
        
        <!-- Form Section -->
        <div class="form-container">
            <div class="box">
            <h2>Personal Details</h2>
        </div>
        <form action="{{route('userupdate',['Email' => $user->Email])}}" method="POST">

        @csrf           
                <div class="form-group">
                    <label>Full Name </label>
                    <input type="text" name="name" value="{{ $user->name }}">

                </div>
                <div class="form-group">
                    <label>Email : </label>
                    <input type="text" name="name" value="{{ $user->Email }}">

                </div>
                <div class="form-group">
                    <label>Phone Numbe</label>
                    <input type="text" name="name" value="{{ $user->Contact }}">

                </div>
                <div class="form-group">
                <label>Gender: </label>
                <input type="text" name="name" value="{{ $user->Gender }}">

                </div>
                 <div class="form-group">
                    <label>Birth Data  </label>
                    <input type="text" name="name" value="{{ $user->Birth }}">

                </div>
               

              <div class="box">
                <h2>Address</h2>
                
              </div>
                <div class="form-group">
                    <label>Address : </label>
                    <input type="text" name="name" value="{{ $user->Address }}">

                </div>
                <button type="submit" class="login-btn">Submit</button>

               
            </form>
        </div>
    </div>
</body>
</html>
@endsection

