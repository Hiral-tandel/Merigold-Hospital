@extends('layout')
@section('content')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile & Form Layout</title>
    <link rel="stylesheet" href="styles.css">
</head>
<style>
    /* General Styles */


/* Container Layout */
.container {
    display: flex;
    background: white;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
    overflow: hidden;
    width: 1540px;
}

/* Profile Section */
.profile {
    width: 30%;
    background: #f9f9f9;
    padding: 20px;
    text-align: center;
    border-right: 1px solid #ddd;
}

.profile img {
    width: 110px;
    height: 110px;
    border-radius: 70%;
    margin-bottom: 10px;
}

.profile h3 {
    margin: 5px 0;
    font-size: 18px;
}

.profile p {
    color: #777;
    font-size: 14px;
}

.profile h4 {
    margin-top: 15px;
    font-size: 16px;
    color: #333;
}

/* Form Section */
.form-container {
    width: 100%;
    padding: 20px;
}

/* Form Group */
.form-group {
    display: inline-block;
    width: 80%;
    margin: 10px 1%;
}

.form-group label {
    display: block;
    font-size: 14px;
    font-weight: bold;
    margin-bottom: 5px;
}

.form-group input {
    width: 100%;
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 14px;
}

/* Button Group */
.btn-group {
    margin-top: 20px;
    text-align: right;
}

button {
    padding: 8px 15px;
    font-size: 14px;
    border: none;
    cursor: pointer;
    border-radius: 5px;
    background-color:#002D72;
    color : #FFFF;


}

button:hover {
    opacity: 0.8;
}
.box{
    background:#002D72;
    border-radius : 5px;
    width: 100%;
height:30px;

}
.box h2{
    color:#FFFF;
    margin-left: 5px;
margin-top: 2px;
}

</style>
<body>
    <div class="container">
        <!-- Profile Section -->
        <div class="profile">
            <img src="/images/profile.png ">

            <h3>{{ $user->name }}</h3>
            <p>{{ $user->Email }}</p>
            
        <a href="{{ route('update', ['Email' => $user->Email]) }}">
        <button type="button" >Edit Profile</button>

          </a>
          <a href="{{ route('logout') }}">
          <button class="cancel"  action="{{ route('logout') }}" >Logout</button>

          </a>

        </div>
        
        <!-- Form Section -->
        <div class="form-container">
            <div class="box">
            <h2>Personal Details</h2>
        </div>
            <form>
                <div class="form-group">
                    <label>Full Name :{{ $user->name }} </label>
                </div>
                <div class="form-group">
                    <label>Email : {{ $user->Email }}</label>
                </div>
                <div class="form-group">
                    <label>Phone Number :{{ $user->Contact }}</label>
                </div>
                <div class="form-group">
                <label>Gender: {{ $user->Gender }}</label>
                </div>
                 <div class="form-group">
                    <label>Birth Data :{{ $user->Birth }} </label>
                </div>
               

              <div class="box">
                <h2>Address</h2>
              </div>
                <div class="form-group">
                    <label>Address :  {{ $user->Address }}</label>
                </div>
               
            </form>
        </div>
    </div>
</body>
</html>
@endsection

